import unittest
from main import UsuarioDAO, CadastroWindow

import mysql.connector
import tkinter as tk
from produto.produto import BancoDeDados


class TestCadastroWindow(unittest.TestCase):
    def setUp(self):
        self.dao = UsuarioDAO()
        self.cadastro_window = CadastroWindow(self.dao)

    def test_criar_conta(self):
        self.cadastro_window.nome_entry.insert(0, "jucaGOD")
        self.cadastro_window.email_entry.insert(0, "juca10@gmail.com")
        self.cadastro_window.senha_entry.insert(0, "123456")
        self.cadastro_window.telefone_entry.insert(0, "12345678")

        self.cadastro_window.criar_conta()


if __name__ == '__main__':
    unittest.main()
