import unittest
from produto import BancoDeDados
import mysql.connector

class TestBancoDeDados(unittest.TestCase):
    def setUp(self):
        self.bd = BancoDeDados()
        self.cursor = self.bd.db.cursor()

    def test_adicionar_produto(self):
        self.bd.adicionar_produto("Fanta", 8, 5)
        self.cursor.execute("SELECT * FROM produtos WHERE nome='Fanta'")
        result = self.cursor.fetchone()
        self.assertEqual(result[1], "Fanta")
        self.assertEqual(result[2], 8)
        self.assertEqual(result[3], 5)

    def tearDown(self):
        self.cursor.execute("DELETE FROM produtos WHERE nome='Fanta'")
        self.bd.db.commit()
        self.bd.db.close()

if __name__ == '__main__':
    unittest.main()
