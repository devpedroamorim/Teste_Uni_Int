import tkinter as tk
from tkinter import messagebox
import mysql.connector


class BancoDeDados:
    def __init__(self):
        self.db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="1234",
            database="mercadinho"
        )
        self.cursor = self.db.cursor()

    def adicionar_produto(self, nome, preco, quantidade):
        self.cursor.execute("INSERT INTO produtos (nome, preco, quantidade) VALUES (%s, %s, %s)",
                            (nome, preco, quantidade))
        self.db.commit()

    def atualizar_produto(self, id, nome, preco, quantidade):
        self.cursor.execute("UPDATE produtos SET nome=%s, preco=%s, quantidade=%s WHERE id=%s",
                            (nome, preco, quantidade, id))
        self.db.commit()

    def remover_produto(self, id):
        self.cursor.execute("DELETE FROM produtos WHERE id=%s", (id,))
        self.db.commit()

    def obter_produtos(self):
        self.cursor.execute("SELECT * FROM produtos")
        produtos = self.cursor.fetchall()
        return produtos

    def obter_produto_por_id(self, id):
        self.cursor.execute("SELECT * FROM produtos WHERE id=%s", (id,))
        produto = self.cursor.fetchone()
        return produto


class InterfaceUsuario:
    def __init__(self):
        self.janela = tk.Tk()
        self.janela.title("Filmes")
        self.janela.config(bg='#391a4a')
        self.janela.resizable(False, False)  # Impede o redimensionamento

        self.box = tk.Listbox(self.janela, width=50)
        self.box.pack(pady=10)
        self.box.config(bg='#453a4a')

        self.atualizar_button = tk.Button(self.janela, text="Atualizar", command=self.atualizar_box, bg="#453a4a", )
        self.atualizar_button.pack(side=tk.LEFT, padx=10)

        self.adicionar_button = tk.Button(self.janela, text="Adicionar", command=self.abrir_tela_cadastro,
                                          bg="#453a4a", )
        self.adicionar_button.pack(side=tk.LEFT, padx=10)

        self.remover_button = tk.Button(self.janela, text="Remover", command=self.remover_produto, bg="#453a4a", )
        self.remover_button.pack(side=tk.LEFT, padx=10)

        self.compra_button = tk.Button(self.janela, text="Realizar Compra", command=self.realizar_compra,
                                       bg="#453a4a", )
        self.compra_button.pack(side=tk.LEFT, padx=10)

        self.atualizar_estoque_button = tk.Button(self.janela, text="Atualizar Estoque",
                                                  command=self.abrir_tela_atualizacao_estoque, bg="#453a4a", )
        self.atualizar_estoque_button.pack(side=tk.LEFT, padx=10)

        self.bd = BancoDeDados()
        self.atualizar_box()

    def atualizar_box(self):
        self.box.delete(0, tk.END)
        produtos = self.bd.obter_produtos()
        for produto in produtos:
            self.box.insert(tk.END, f"{produto[0]} - {produto[1]} - R${produto[2]} - {produto[3]} unidades")

    def abrir_tela_cadastro(self):
        self.tela_cadastro = tk.Toplevel(self.janela)
        self.tela_cadastro.title("Cadastro de Produto")

        nome_label = tk.Label(self.tela_cadastro, text="Nome:")
        nome_label.pack(pady=10)
        self.nome_entry = tk.Entry(self.tela_cadastro)
        self.nome_entry.pack()

        preco_label = tk.Label(self.tela_cadastro, text="Preço:")
        preco_label.pack(pady=10)
        self.preco_entry = tk.Entry(self.tela_cadastro)
        self.preco_entry.pack()

        quantidade_label = tk.Label(self.tela_cadastro, text="Quantidade:")
        quantidade_label.pack(pady=10)
        self.quantidade_entry = tk.Entry(self.tela_cadastro)
        self.quantidade_entry.pack()

        cadastrar_button = tk.Button(self.tela_cadastro, text="Cadastrar", command=self.cadastrar_produto)
        cadastrar_button.pack(pady=10)

    def cadastrar_produto(self):
        nome = self.nome_entry.get()
        preco = float(self.preco_entry.get())
        quantidade = int(self.quantidade_entry.get())

        self.bd.adicionar_produto(nome, preco, quantidade)
        self.tela_cadastro.destroy()
        self.atualizar_box()

    def remover_produto(self):
        produto_selecionado = self.box.curselection()
        if produto_selecionado:
            id = int(self.box.get(produto_selecionado[0]).split("-")[0].strip())
            self.bd.remover_produto(id)
            self.atualizar_box()
        else:
            messagebox.showwarning("Atenção", "Selecione um produto para remover")

    def realizar_compra(self):
        self.tela_compra = tk.Toplevel(self.janela)
        self.tela_compra.title("Realizar Compra")

        produto_label = tk.Label(self.tela_compra, text="Produto:")
        produto_label.pack(pady=10)
        self.produto_entry = tk.Entry(self.tela_compra)
        self.produto_entry.pack()

        quantidade_label = tk.Label(self.tela_compra, text="Quantidade:")
        quantidade_label.pack(pady=10)
        self.quantidade_entry = tk.Entry(self.tela_compra)
        self.quantidade_entry.pack()

        comprar_button = tk.Button(self.tela_compra, text="Comprar", command=self.comprar_produto)
        comprar_button.pack(pady=10)

    def comprar_produto(self):
        produto_id = int(self.produto_entry.get().split("-")[0].strip())
        produto = self.bd.obter_produto_por_id(produto_id)
        quantidade_compra = int(self.quantidade_entry.get())

        if produto:
            if produto[3] >= quantidade_compra:
                self.bd.atualizar_produto(produto_id, produto[1], produto[2], produto[3] - quantidade_compra)
                self.tela_compra.destroy()
                self.atualizar_box()
            else:
                messagebox.showwarning("Atenção", "Quantidade insuficiente em estoque")
        else:
            messagebox.showwarning("Atenção", "Produto não encontrado")

    def abrir_tela_atualizacao_estoque(self):
        # Cria a nova janela para atualização de estoque
        self.janela_atualizacao_estoque = tk.Toplevel(self.janela)
        self.janela_atualizacao_estoque.title("Atualização de Estoque")

        # Cria o label para o ID do produto
        id_label = tk.Label(self.janela_atualizacao_estoque, text="ID do Produto:")
        id_label.grid(row=0, column=0, padx=5, pady=5)

        # Cria a entrada de texto para o ID do produto
        self.id_entry = tk.Entry(self.janela_atualizacao_estoque, width=30)
        self.id_entry.grid(row=0, column=1, padx=5, pady=5)

        # Cria o label para a quantidade a ser adicionada
        quantidade_label = tk.Label(self.janela_atualizacao_estoque, text="Quantidade:")
        quantidade_label.grid(row=1, column=0, padx=5, pady=5)

        # Cria a entrada de texto para a quantidade a ser adicionada
        self.quantidade_entry = tk.Entry(self.janela_atualizacao_estoque, width=30)
        self.quantidade_entry.grid(row=1, column=1, padx=5, pady=5)

        # Cria o botão para realizar a atualização de estoque
        atualizar_button = tk.Button(self.janela_atualizacao_estoque, text="Atualizar", command=self.atualizar_estoque)
        atualizar_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        # Define o tamanho e a posição da janela
        self.janela_atualizacao_estoque.geometry("300x150+500+300")

    def atualizar_estoque(self):
        # Obtém o ID e a quantidade a ser adicionada
        id = self.id_entry.get()
        quantidade = self.quantidade_entry.get()

        # Verifica se o ID e a quantidade foram fornecidos
        if id == "" or quantidade == "":
            messagebox.showerror("Erro", "Por favor, preencha todos os campos.")
            return

        # Verifica se o ID é válido
        try:
            id = int(id)
        except ValueError:
            messagebox.showerror("Erro", "O ID deve ser um número inteiro.")
            return

        # Verifica se a quantidade é válida
        try:
            quantidade = int(quantidade)
        except ValueError:
            messagebox.showerror("Erro", "A quantidade deve ser um número inteiro.")
            return

        # Obtém o produto com o ID fornecido
        produto = self.bd.obter_produto_por_id(id)

        # Verifica se o produto existe
        if produto is None:
            messagebox.showerror("Erro", f"O produto com ID {id} não foi encontrado.")
            return

        # Atualiza a quantidade do produto
        nova_quantidade = produto[3] + quantidade
        self.bd.atualizar_produto(id, produto[1], produto[2], nova_quantidade)

        # Fecha a janela de atualização de estoque
        self.janela_atualizacao_estoque.destroy()

        # Atualiza a lista de produtos na box
        self.atualizar_box()

        # Exibe uma mensagem de sucesso
        messagebox.showinfo("Sucesso", f"A quantidade do produto {produto[1]} foi atualizada para {nova_quantidade}.")


def abrir_tela_atualizacao_estoque(self):
    # Cria a nova janela para atualização de estoque
    self.janela_atualizacao_estoque = tk.Toplevel(self.janela)
    self.janela_atualizacao_estoque.title("Atualização de Estoque")

    # Cria o label para o ID do produto
    id_label = tk.Label(self.janela_atualizacao_estoque, text="ID do Produto:")
    id_label.grid(row=0, column=0, padx=5, pady=5)

    # Cria a entrada de texto para o ID do produto
    self.id_entry = tk.Entry(self.janela_atualizacao_estoque, width=30)
    self.id_entry.grid(row=0, column=1, padx=5, pady=5)

    # Cria o label para a quantidade a ser adicionada
    quantidade_label = tk.Label(self.janela_atualizacao_estoque, text="Quantidade:")
    quantidade_label.grid(row=1, column=0, padx=5, pady=5)

    # Cria a entrada de texto para a quantidade a ser adicionada
    self.quantidade_entry = tk.Entry(self.janela_atualizacao_estoque, width=30)
    self.quantidade_entry.grid(row=1, column=1, padx=5, pady=5)

    # Cria o botão para realizar a atualização de estoque
    atualizar_button = tk.Button(self.janela_atualizacao_estoque, text="Atualizar", command=self.atualizar_estoque)
    atualizar_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

    # Define o tamanho e a posição da janela
    self.janela_atualizacao_estoque.geometry("300x150+500+300")


def atualizar_estoque(self):
    # Obtém o ID e a quantidade a ser adicionada
    id = self.id_entry.get()
    quantidade = self.quantidade_entry.get()

    # Verifica se o ID e a quantidade foram fornecidos
    if id == "" or quantidade == "":
        messagebox.showerror("Erro", "Por favor, preencha todos os campos.")
        return

    # Verifica se o ID é válido
    try:
        id = int(id)
    except ValueError:
        messagebox.showerror("Erro", "O ID deve ser um número inteiro.")
        return

    # Verifica se a quantidade é válida
    try:
        quantidade = int(quantidade)
    except ValueError:
        messagebox.showerror("Erro", "A quantidade deve ser um número inteiro.")
        return

    # Obtém o produto com o ID fornecido
    produto = self.bd.obter_produto_por_id(id)

    # Verifica se o produto existe
    if produto is None:
        messagebox.showerror("Erro", f"O produto com ID {id} não foi encontrado.")
        return

    # Atualiza a quantidade do produto
    nova_quantidade = produto[3] + quantidade
    self.bd.atualizar_produto(id, produto[1], produto[2], nova_quantidade)

    # Fecha a janela de atualização de estoque
    self.janela_atualizacao_estoque.destroy()

    # Atualiza a lista de produtos na box
    self.atualizar_box()

    # Exibe uma mensagem de sucesso
    messagebox.showinfo("Sucesso", f"A quantidade do produto {produto[1]} foi atualizada para {nova_quantidade}.")


if __name__ == '__main__':
    InterfaceUsuario()
    tk.mainloop()


