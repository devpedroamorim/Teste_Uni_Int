import unittest
import tkinter as tk
from unittest.mock import MagicMock, patch
import mysql.connector
from produto import BancoDeDados, InterfaceUsuario

# TESTES UNITARIOS

class TestBancoDeDados(unittest.TestCase):
    def setUp(self):
        with patch.object(mysql.connector, 'connect'):
            self.bd = BancoDeDados()

    def test_adicionar_produto(self):
        self.bd.cursor = MagicMock()
        self.bd.adicionar_produto("Coca-Cola", 7.99, 5)
        self.bd.cursor.execute.assert_called_with("INSERT INTO produtos (nome, preco, quantidade) VALUES (%s, %s, %s)", ("Coca-Cola", 7.99, 5))
        self.bd.db.commit.assert_called_once()

    def test_remover_produto(self):
        self.bd.cursor = MagicMock()
        self.bd.remover_produto(1)
        self.bd.cursor.execute.assert_called_with("DELETE FROM produtos WHERE id=%s", (1,))
        self.bd.db.commit.assert_called_once()

class TestInterfaceUsuario(unittest.TestCase):
    def setUp(self):
        with patch.object(BancoDeDados, 'obter_produtos', return_value=[]):
            self.ui = InterfaceUsuario()

    def test_atualizar_box(self):
        with patch.object(self.ui.bd, 'obter_produtos', return_value=[(1, "Coca-Cola", 7.99, 5)]):
            self.ui.box.delete = MagicMock()
            self.ui.box.insert = MagicMock()
            self.ui.atualizar_box()
            self.ui.box.insert.assert_called_with(tk.END, "1 - Coca-Cola - R$7.99 - 5 unidades")

if __name__ == '__main__':
    unittest.main()
